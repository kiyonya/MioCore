import EventEmitter from "events";
import fs from 'fs'
import path from "path";
import HashUtil from "../../utils/hash.ts";
import pLimit from "p-limit";
import { existify } from "../../utils/io.ts";

interface ResourcesStoreOptions {
    storePath: string
}

export default class ResourcesStore {

    public storePath: string

    constructor(options: ResourcesStoreOptions) {
        this.storePath = existify(options.storePath)
    }

    public async inStore(versionPath: string, dirs: string[], removeRaw: boolean = false) {

        for (const dir of dirs) {
            const dirPath = path.join(versionPath, dir)
            if (!fs.existsSync(dirPath)) continue

            const files = fs.readdirSync(dirPath).map(i => path.join(dirPath, i)).filter(i => !fs.statSync(i).isDirectory()).filter(i => path.extname(i) !== '.store')

            const limit = pLimit(120)
            const hashPromises: Promise<{ file: string, sha1: string }>[] = files.map(file => limit(() => new Promise((resolve, reject) => {
                HashUtil.sha1(file).then(sha1 => resolve({ file, sha1 })).catch(reject)
            })))
            const hashes = await Promise.all(hashPromises)
            const storeDir = existify(this.storePath, dir)
            const storeIndex: { fileName: string, sha1: string, store: string }[] = []

            for (const hash of hashes) {
                const fileName = path.basename(hash.file)
                const sha1 = hash.sha1
                storeIndex.push({
                    fileName, sha1, store: storeDir
                })
                const destHashDir = existify(storeDir, sha1.slice(0, 2))
                const destFile = path.join(destHashDir, (sha1 + path.extname(hash.file)).replace('.disabled', '.jar'))
                fs.copyFileSync(hash.file, destFile)
                fs.writeFileSync(path.join(dirPath, 'index.store'), JSON.stringify(storeIndex), 'utf-8')

                console.log(removeRaw)
                if (removeRaw) {
                    fs.unlinkSync(hash.file)
                }
            }
        }
    }

    public async outStore(versionPath: string, dirs: string[]): Promise<string[]> {
        const pulled: string[] = []

        for (const dir of dirs) {
            const destPath = existify(versionPath, dir)
            const storeIndexPath = path.join(destPath, 'index.store')
            const storeIndexBackupPath = path.join(destPath, 'index.old.store')

            let storeIndexJsonPath

            if (fs.existsSync(storeIndexPath)) {
                storeIndexJsonPath = storeIndexPath
            } else if (fs.existsSync(storeIndexBackupPath)) {
                storeIndexJsonPath = storeIndexBackupPath
                const backupData = fs.readFileSync(storeIndexBackupPath, 'utf-8')
                fs.writeFileSync(storeIndexPath, backupData, 'utf-8')
                console.log(`已从备份文件还原 index.store`)
            } else {
                continue
            }

            const storeIndexJson = JSON.parse(fs.readFileSync(storeIndexJsonPath, 'utf-8'))

            // 更新备份
            fs.writeFileSync(storeIndexBackupPath, JSON.stringify(storeIndexJson), 'utf-8')

            for (const index of storeIndexJson) {
                const { fileName, sha1, store } = index
                const storeFilePath = path.join(store, sha1.slice(0, 2), sha1 + path.extname(fileName))
                if (!fs.existsSync(storeFilePath)) throw new Error("FILE NOT FOUND")
                fs.copyFileSync(storeFilePath, path.join(destPath, fileName))
                pulled.push(path.join(destPath, fileName))
            }

        }
        return pulled
    }

    public recycle(versionPath: string, dirs: string[]) {
        for (const dir of dirs) {
            const destPath = path.join(versionPath, dir)
            if (fs.existsSync(destPath)) {
                const recycleFiles = fs.readdirSync(destPath).map(i => path.join(destPath, i)).filter(i => path.extname(i) !== ".store")
                for (const f of recycleFiles) {
                    fs.unlinkSync(f)
                }
            }
        }
    }

    public async restore(versionPath: string, dirs: string[]): Promise<string[]> {
        const restored = await this.outStore(versionPath, dirs)
        for (const dir of dirs) {
            const destPath = existify(versionPath, dir)
            const storeIndexFiles = fs.readdirSync(destPath).map(i => path.join(destPath, i)).filter(i => path.extname(i) === ".store")
            for (const indexf of storeIndexFiles) {
                fs.rmSync(indexf, { force: true })
            }
        }
        return restored
    }

}