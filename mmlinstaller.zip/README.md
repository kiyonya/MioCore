## Mio Launch Lib - Renew

> ℹ️ **Tips**
> 本项目是基于 [mmlib](https://github.com/kiyonya/mmlib) 重构的 Node.js 库

**Mio Launch Lib** 是一个专为 Windows 平台设计的 Node.js 库，用于**自动化安装和启动 Minecraft Java Edition**


